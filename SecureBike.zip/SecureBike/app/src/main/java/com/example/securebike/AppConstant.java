package com.example.securebike;

public class AppConstant {
    public static String BaseURL="SecureBike";

}
